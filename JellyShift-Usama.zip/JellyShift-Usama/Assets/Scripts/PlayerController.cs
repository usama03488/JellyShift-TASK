﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    private float posdown, posUp;
    private Rigidbody rigidbody;
    private bool isCollided = false;
    AudioSource sound;
    Vector3 tempScale;
   public ParticleSystem ps;
    // Start is called before the first frame update
    void Start()
    {
        rigidbody = gameObject.GetComponent<Rigidbody>();
        sound = gameObject.GetComponent<AudioSource>();
   
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetMouseButton(0))
        {
            Debug.Log("mouse button presses "+ Input.mousePosition.y);
        }

        //if (Input.GetMouseButtonDown(0))
        //{
        //    posdown = Input.mousePosition.y;
        //}
        //if (Input.GetMouseButtonUp(0))
        //{
        //    posUp = Input.mousePosition.y;
        //    if (posdown > posUp)
        //    {
        //        Debug.Log("Mouse sipe down"+posdown);
        //    }
        //    else if (posUp > posdown)
        //    {
        //        Debug.Log("Mouse sipe up"+posUp);
        //    }
        //}

        //PLayer scaling
        if (Input.GetKey(KeyCode.W) && transform.localScale.y <= 3)
        {
            tempScale = transform.localScale;
            tempScale.y += 0.1f;
            tempScale.x -= 0.1f;
            transform.localScale = tempScale;
        }
        if (Input.GetKey(KeyCode.S) && transform.localScale.x <= 3)
        {
            tempScale = transform.localScale;
            tempScale.y -= 0.1f;
            tempScale.x += 0.1f;
            transform.localScale = tempScale;
        }
        if (isCollided == false)
        {
            rigidbody.AddForce(Vector3.forward*Time.deltaTime*50f ,ForceMode.Impulse);
        }
     
        //if (Input.GetKey(KeyCode.W))
        //{
        //    if (transform.localScale.y < 5f&& transform.localScale.x>0.5f)
        //    {
        //        transform.localScale += new Vector3(-0.5f * Time.deltaTime, 1f * Time.deltaTime, 0f);
        //    }

        //}
        //if (Input.GetKey(KeyCode.S))
        //{
        //    if (transform.localScale.x < 5f && transform.localScale.y>0.5f)
        //    {
        //        transform.localScale += new Vector3(1f * Time.deltaTime, -0.5f * Time.deltaTime, 0f);
        //    }

        //}
    }
    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.CompareTag("Hurdles"))
        {
           
            rigidbody.AddForce(Vector3.back * Time.deltaTime * 500f, ForceMode.Impulse);
           
        }
        
    }
    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.CompareTag("Passed"))
        {
            //rigidbody.AddForce(Vector3.forward * Time.deltaTime * 200f, ForceMode.Impulse);
            sound.Play();
            ps.Play();
        }
    }
}
