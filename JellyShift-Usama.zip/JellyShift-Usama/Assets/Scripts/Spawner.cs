﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Spawner : MonoBehaviour
{
   public GameObject[] objects;
    public GameObject playerposition;
    int instatiatedObjects = 0;
    // Start is called before the first frame update
    void Start()
    {

        InvokeRepeating("ObjectSpawner",1f,2f);

    }

    // Update is called once per frame
    void Update()
    {
        
    }
 
    void ObjectSpawner()
    {
        int i = Random.RandomRange(0, objects.Length);
       
        Instantiate(objects[i],new Vector3(objects[i].transform.position.x, objects[i].transform.position.y, playerposition.transform.position.z+20f),objects[i].transform.rotation);
        instatiatedObjects++;
    }

}
